#!/bin/bash
docker build -t admin/adminfaces ../