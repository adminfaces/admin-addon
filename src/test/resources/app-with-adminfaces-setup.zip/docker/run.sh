#!/bin/bash
docker run -it --rm --name AdminFaces -p 8080:8080 admin/AdminFaces