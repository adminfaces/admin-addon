#!/bin/bash
docker run -it --rm --name adminfaces -p 8080:8080 admin/adminfaces