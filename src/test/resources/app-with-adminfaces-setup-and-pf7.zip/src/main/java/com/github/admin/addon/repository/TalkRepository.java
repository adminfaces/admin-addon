package com.github.admin.addon.repository;

import org.apache.deltaspike.data.api.EntityRepository;
import org.apache.deltaspike.data.api.Repository;
import com.github.admin.addon.model.Talk;

@Repository
public interface TalkRepository extends EntityRepository<Talk,Long> {

}