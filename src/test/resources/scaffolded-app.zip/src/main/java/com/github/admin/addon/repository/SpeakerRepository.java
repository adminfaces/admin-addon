package com.github.admin.addon.repository;

import org.apache.deltaspike.data.api.EntityRepository;
import org.apache.deltaspike.data.api.Repository;
import com.github.admin.addon.model.Speaker;

@Repository
public interface SpeakerRepository extends EntityRepository<Speaker,Long> {

}