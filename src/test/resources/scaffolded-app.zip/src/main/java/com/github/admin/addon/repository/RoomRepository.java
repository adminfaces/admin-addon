package com.github.admin.addon.repository;

import org.apache.deltaspike.data.api.EntityRepository;
import org.apache.deltaspike.data.api.Repository;
import com.github.admin.addon.model.Room;

@Repository
public interface RoomRepository extends EntityRepository<Room,Long> {

}